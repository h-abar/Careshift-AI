<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile NphiesEncounter
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Encounter</sch:title>
    <sch:rule context="f:Encounter">
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-emergencyArrivalCode']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-emergencyArrivalCode': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-emergencyServiceStart']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-emergencyServiceStart': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageCategory']) &gt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageCategory': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageCategory']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageCategory': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageDate']) &gt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageDate': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageDate']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-triageDate': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-causeOfDeath']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-causeOfDeath': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-emergencyDepartmentDisposition']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-emergencyDepartmentDisposition': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-serviceEventType']) &gt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-serviceEventType': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-serviceEventType']) &lt;= 1">extension with URL = 'http://nphies.sa/fhir/ksa/nphies-fs/StructureDefinition/extension-serviceEventType': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
